#!/usr/bin/env sh
set -eu
latexmk -interaction=nonstopmode main.tex


